#ifndef LOGIC_H
#define LOGIC_H

#include <random>

#include "screen.h"

using namespace std;

// Coords def
typedef struct coords{
	int x;
	int y;
} coords;

extern coords fruit_coords;

random_device rd;  // a seed source for the random number engine
mt19937 gen(rd()); // mersenne_twister_engine seeded with rd()

// Random X Y coords
uniform_int_distribution<> randX(0, WIDTH-1);
uniform_int_distribution<> randY(0, HEIGHT-1);

void updateFruitCoords(void);

#endif